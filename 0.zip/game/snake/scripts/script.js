      var info = "Съешьте 50 ягод чтоб победить"
      alert ("Съешьте 50 ягод чтоб победить")
      var canvas = document.getElementById("canvas");
      var ctx = canvas.getContext("2d");
      var snake = [];
      //Create an array of objects of x and y coordinates
      for(j = 0; j < 20; j++){
        snake.push({x: 150 - (j * 10), y: 150})
      }
      var dx = 10;
      var dy = 0;
      var food = {
        x: 0,
        y: 0,
        live: false
      }
      var headColor = true;
      var score = 0;

      function drawSnake(){
        headColor = true;
        //Draw eveey parts of the snake
        snake.forEach(function(parts){
          ctx.fillStyle = "green";
          if(headColor){
            ctx.fillStyle = "orange";
          }
          ctx.beginPath()
          ctx.arc(parts.x + 5, parts.y + 5, 5, 0, Math.PI * 2)
          ctx.fill();
          headColor = false;
        })
      }

      function move(){
        //Insert a new part in the head and remove the last
        const head = {x: snake[0].x + dx, y: snake[0].y + dy};
        snake.unshift(head);
        snake.pop();
      }

      function random(){
        return Math.floor(Math.random() * 50) * 10;
      }

      function checkFood(){
        for(part of snake){
          if(part.x == food.x && part.y == food.y){
            return false;
          }
        }
        return true;
      }

      function createFood(){
        if(!food.live){
          food.x = random();
          food.y = random();
          while(!checkFood()){
            food.x = random();
            food.y = random();
          }
          food.live = true;
        }
      }

      function drawFood(){
        //Create and draw food randomly
        createFood();
        ctx.fillStyle = "red";
        ctx.fillRect(food.x, food.y, 10, 10)
      }

      function ifLose(){
        for(i = 1; i < snake.length; i++){
          if(snake[0].x == snake[i].x && snake[0].y == snake[i].y){
            return true;
          }
        }
      }

      function check(){
        //If food is eaten add new part in the head
        if(snake[0].x == food.x && snake[0].y == food.y){
          food.live = false;
          snake.unshift({x: snake[0].x + dx, y: snake[0].y + dy});
          score ++;
          if(score >= 50){
            alert("Вы выйграли съев 50 яблок вы прошли змейку")
            clearInterval(frame);
          }
        }
        if(snake[0].x >= canvas.width){
          snake[0].x = 0
        }
        else if(snake[0].x < 0 ){
          snake[0].x = canvas.width;
        }
        else if(snake[0].y >= canvas.height){
          snake[0].y = 0 
        }
        else if(snake[0].y < 0){
          snake[0].y = canvas.height; 
        }

        if(ifLose()){
          alert("К сожалению вы проиграли.")
          clearInterval(frame);
        }
      }

      function drawScore(){
        ctx.beginPath();
        ctx.fillStyle = "black"
        ctx.font = "15px Arial"
        ctx.fillText("Рекорд:" + score, canvas.width - 70, 20)
      }

      var frame = setInterval(function(){
        ctx.clearRect(0, 0, canvas.width, canvas.height)
        move();
        check();
        drawSnake();
        drawFood();
        drawScore();
      }, 100)



      var startX;
      var startY;
      var endX;
      var endY;

      function handleTouch(start,end, cbL, cbR){
        var xDist = endX - startX;
        var yDist = endY - startY;

        if(Math.abs(xDist) > Math.abs(yDist)){
          if(xDist > 0 && dx != -10){
            direction("right")
          }
          else if(xDist < 0 && dx != 10){
            direction("left")
          }
        }
        else{
          if(yDist > 0 && dy != -10){
            direction("down")
          }
          else if(yDist < 10 && dy != 10){
            direction("up")
          }
        }
      }

      window.onload = function(){
        var button = document.getElementById("button");
        button.addEventListener("click", function(){
          alert(info)
        })

        //Detect the coordinates of the start of touch
        window.addEventListener('touchstart', function(event){
          startX = event.touches[0].clientX;
          startY = event.touches[0].clientY;
        })
        //Detect the coordinates of the end of touch  
        window.addEventListener('touchend', function(event){
        endX = event.changedTouches[0].clientX;
        endY = event.changedTouches[0].clientY;

        handleTouch()
        })

        document.addEventListener("keydown", keyDownHandler, false);
        //Checking the pressed key
        function keyDownHandler(e){
          if(e.keyCode == 39 && dx != -10){
            direction("right")
          }
          else if(e.keyCode == 37 && dx != 10){
            direction("left")
          }
          else if(e.keyCode == 40 && dy != -10){
            direction("down")
          }
          else if(e.keyCode == 38 && dy != 10){
            direction("up")
          }
        }
      }

      function direction(direct){
        switch(direct){
          case "right":
            dx = 10;
            dy = 0;
            break;
          case "left":
            dx = -10;
            dy = 0;
            break;
          case "down":
            dy = 10;
            dx = 0;
            break;
          case "up":
            dy = -10;
            dx = 0;
            break;
        }
      }