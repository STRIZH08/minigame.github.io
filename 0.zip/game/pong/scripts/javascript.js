let ctx,cvs,w,h,player,ai,ball,gameOver=false,start=false,aiScore=0,aiLevel = 0.034,plyScore=0,board,dx=4,dy=4;
const {pow,abs,random,floor} = Math;
const setLevel =(e,vel)=>{
if(!gameOver){
  start = true;
   aiLevel = e;
   dx = vel;dy=vel;
document.querySelector("#aiLevel").style.display = "none";           document.querySelector("canvas").style.display ="block";   
   init();
   let arr= [pop,pop1,pop2,pop3];
   arr[floor(random()*arr.length)].play();
 }
}
window.onload= ()=>document.querySelector("#aiLevel").style.display ="block";loader.style.display="none";
const init =()=>{
    cvs = document.querySelector("canvas");
    w = cvs.width = window.innerWidth/1.2 || innerWidth/1.2;
    h = cvs.height = window.innerHeight/1.2 || innerHeight/1.2;
    ctx = cvs.getContext("2d");
    ai = new Player (w/2-35,10);
    player = new Player(w/2-35,h-20);
    ball = new Ball(w/2,h/2);
    board = new ScoreBoard(aiScore,plyScore);    
    requestAnimationFrame(draw);
}
const draw =()=>{
 if(!gameOver){
 requestAnimationFrame(draw);
 ctx.clearRect(0,0,w,h);
 player.show();
 ai.show();
 board.show();
 ball.show();
 ball.update();
 ai.update();
 if (collision(player, ball)) {ball.y=player.y-ball.r;ball.velY *=-1; }
 else if(collision(ai,ball)){ball.y=ai.y+ai.h+ball.r;ball.velY *=-1 };
 if(aiScore>5||plyScore>5)gameover();
 }  
}
window.ontouchmove=(e)=>{
  if(start)player.x= parseInt(e.changedTouches[0].clientX) - cvs.getBoundingClientRect().top - document.documentElement.scrollTop-(player.w/2);
}
let collision=(a,b)=>{
let distX =abs(b.x - a.x-a.w/2); 
let distY =abs(b.y - a.y-a.h/2); 
if(distX>(a.w/2+b.r))return false;
if(distY>(a.h/2+b.r))return false;  
if(distX <= (a.w/2))return true; 
if (distY <= (a.h/2))return true;
return (pow(distX-a.w/2,2)+pow(distY-a.h/2,2)<=(pow(b.r,2)));
}
const gameover =()=>{
   gameOver = true;   
   start = false; document.querySelector("canvas").style.display ="none";
document.querySelector("#aiLevel").style.display = "block";     
show_result("Игра Окончена!\nХорошо Сыграли");
   
}
class Player{
  constructor(x,y){
    this.x = x;
    this.y = y;
    this.w = 40;
    this.h = 4;
  }
   show(){
  ctx.fillStyle="#000";                                                                                                                  
  ctx.fillRect(this.x,this.y,this.w,this.h);
    }
   update(){
       this.x += (ball.x - (this.x +this.w/2))*aiLevel;   
   }
}
class Ball{
    constructor(x,y){
       this.x = x;
       this.y = y;
       this.r = 4; 
       this.velX = dx;
       this.velY = dy;
    }
    show(){
    ctx.beginPath();
        ctx.fillStyle = "red";
        ctx.arc(this.x,this.y,this.r,2*Math.PI,false);
        ctx.fill();
    ctx.closePath();
    }
   update(){
        this.x+=this.velX;
        this.y+=this.velY;
        if(this.x+this.r>w)this.velX*=-1;         
        else if(this.x<this.r)this.velX*=-1;        
        else if(this.y>h+this.r){ball=new Ball(w/2,h/2);aiScore++;}     
        else if(this.y<0){ball=new Ball(w/2,h/2);plyScore++; }           
    }
}
class ScoreBoard{
    constructor(score1,score2){
        this.score1 = score1;
        this.score2 = score2;
    }
    show(){
    ctx.beginPath();
       ctx.lineWidth = 1;
       ctx.setLineDash([4, 2]);
       ctx.strokeStyle = "#000";
       ctx.moveTo(0,h/2);
       ctx.lineTo(w,h/2);
       ctx.font = "bold 20px sans-serif"
       ctx.fillText(aiScore,w/2,h/2-20);
       ctx.fillText(plyScore,w/2,h/2+30);
       ctx.stroke();
    ctx.closePath();
  }
}
const show_result=(e)=>{
    data.innerText=e;
    result.style.visibility = "visible";
    result.style.left ="50%";
}
const hide_result=()=>{
    result.style.left ="-50%";
    result.style.visibility = "hidden";   
    gameOver =false;aiScore =0;
    plyScore =0;dx = 3;dy =3;
    ai = new Player (w/2-35,10);
    player = new Player(w/2-35,h-20);
    ball = new Ball(w/2,h/2);
    board = new ScoreBoard(aiScore,plyScore);
}  